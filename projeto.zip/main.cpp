// #include "character.hpp"

#include "game.hpp"

int main() {
    Game capture_flag = Game(5);
    capture_flag.execute_game();

    return 0;
}